# About Me

I'm Link — a retired Army veteran with over 30 years of service in leadership, recruiting, and career counseling.

CallMeLink.org is my way of giving back: offering honest, tactical, and encouraging support to anyone navigating the next step in their career.

---

## My Core Values

- Purpose over position
- Service over status
- Growth over guarantees
