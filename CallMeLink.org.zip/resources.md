# Resources

## Free Downloads
- Resume templates
- Cover letter guides
- Transition checklists

## Recommended Tools
- Job boards for veterans
- LinkedIn starter tips
- VA benefits navigators
